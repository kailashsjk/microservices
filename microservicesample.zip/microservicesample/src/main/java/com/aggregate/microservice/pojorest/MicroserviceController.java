package com.aggregate.microservice.pojorest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
@RequestMapping("/microservice")
public class MicroserviceController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@RequestMapping("/ReadAll")
	public Iterable<Object> readAllMongoDB() {
		
		List<Object> mongodb=new ArrayList<Object>();
		List<Object> mySQL=new ArrayList<Object>();
		List<Object> merge=new ArrayList<Object>();
		try{				
			mongodb = Arrays.asList(restTemplate.getForObject("http://localhost:8077/booking/read-all", Object[].class));
			mySQL = Arrays.asList(restTemplate.getForObject("http://localhost:8181/booking/readAll", Object[].class));
			merge = new ArrayList<Object>(mongodb);
			merge.addAll(mySQL);
		
		
		
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return merge;
		
	}
	
	/*@RequestMapping("/mySQLCreate")
	public Object createMySQL(@Valid @RequestBody Object object) {
		
		try{	
			object=restTemplate.postForObject("http://localhost:8181/booking/create",object,Object.class);
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return object;
		
	}
	
	@RequestMapping("/mySQLUpdate")
	public Object updateMySQL(@Valid @RequestBody Object object) {
		
		try{	
	
			object=restTemplate.postForObject("http://localhost:8181/booking/update",object,Object.class);
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return object;
		
	}
	
	@RequestMapping("/mySQLRead")
	public Object readMySQL(@Valid @RequestBody Object object) {
				
		try{	
			
			object=restTemplate.postForObject("http://localhost:8181/booking/read",object,Object.class);
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return object;
		
	}
	
	
	
	@RequestMapping("/mySQLDelete")
	public Map<String, Object> deleteMySQL(@Valid @RequestBody Object object) {
		Map<String, Object> dataMap = new HashMap<String, Object>();
		try{	
			
			object=restTemplate.postForObject("http://localhost:8181/booking/delete",object,Object.class);
			dataMap.put("bookingId", object);
			dataMap.put("Status", "Successfully Deleted");
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return dataMap;
		
	}

	@RequestMapping("/mongoDBCreate")
	public Object createMongoDB(@Valid @RequestBody Object object) {		
		try{			
			object=restTemplate.postForObject("http://localhost:8077/booking/create",object,Object.class);				
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
			
		}
		return object;
	}
	
	@RequestMapping("/mongoDBUpdate")
	public Object updateMongoDB(@Valid @RequestBody Object object) {
		
		try{	
	
			object=restTemplate.postForObject("http://localhost:8077/booking/update",object,Object.class);
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return object;
		
	}
	
	
	@RequestMapping("/mongoDBRead")
	public Object readMongoDB(@Valid @RequestBody Object object) {
		
		try{			
			
			object=restTemplate.postForObject("http://localhost:8077/booking/read",object,Object.class);		
			
			
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return object;
		
	}
	

	
	@RequestMapping("/mongoDBDelete")
	public Map<String, Object> deleteMongoDB(@Valid @RequestBody Object object) {
		Map<String, Object> dataMap = new HashMap<String, Object>();
		try{	
			
			
			
			object=restTemplate.postForObject("http://localhost:8077/booking/delete",object,Object.class);
			
			dataMap.put("Object", object);
			dataMap.put("Status", "Successfully Deleted");
		
		}catch(Exception e){
			System.out.println("Connection Exception"+e.getMessage());
		}
		return dataMap;
		
	}
	
	*/
	
	
	
	
}
